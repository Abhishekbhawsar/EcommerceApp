import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controller/CartController.dart';
import '../controller/ProductController.dart';


class ProductDetailsScreen extends StatefulWidget {
  final int productId;

  ProductDetailsScreen({required this.productId});

  @override
  _ProductDetailsScreenState createState() => _ProductDetailsScreenState();
}

class _ProductDetailsScreenState extends State<ProductDetailsScreen> {
  late ProductController productController;
  final CartController cartController = Get.put(CartController());

  @override
  void initState() {
    super.initState();
    productController = Get.put(ProductController());
    productController.fetchProductDetails(widget.productId);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Product Details'),
      ),
      body: Obx(() {
        if (productController.isLoading.value) {
          return Center(child: CircularProgressIndicator());
        } else if (productController.product.isEmpty) {
          return Center(child: Text('Product not found'));
        } else {
          return Padding(
            padding: EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(productController.product['title'], style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                SizedBox(height: 8),
                Image.network(productController.product['image'], height: 200),
                SizedBox(height: 8),
                Text('\$${productController.product['price']}', style: TextStyle(fontSize: 20, color: Colors.green)),
                SizedBox(height: 8),
                Text(productController.product['description']),
                SizedBox(height: 8),
                Text('Category: ${productController.product['category']}'),
                SizedBox(height: 16),
                ElevatedButton(
                  onPressed: () {
                    cartController.addToCart(1, widget.productId, 1); // Example userId = 1, quantity = 1
                  },
                  child: Text('Add to Cart'),
                ),
              ],
            ),
          );
        }
      }),
    );
  }
}
