import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_state_manager/src/rx_flutter/rx_obx_widget.dart';

import '../controller/CategoryController.dart';
import 'ProductDetailsScreen.dart';

class CategoryScreen extends StatefulWidget {
  @override
  _CategoryScreenState createState() => _CategoryScreenState();
}

class _CategoryScreenState extends State<CategoryScreen> {

  final CategoryController categoryController = Get.put(CategoryController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Product Categories'),
      ),
      body: Obx(() {
        if (categoryController.isLoading.value) {
          return Center(child: CircularProgressIndicator());
        } else {
          return ListView.builder(
            itemCount: categoryController.categories.length,
            itemBuilder: (context, index) {
              return InkWell(
                  onTap: () {
                // Assuming you want to pass the category as the productId for this example
                Get.to(() => ProductDetailsScreen(productId: index + 1)); // Pass the productId dynamically
              },child:ListTile(
                title: Text(categoryController.categories[index]),
              ));
            },
          );
        }
      }),
    );
  }
}
