import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../auth/LoginScreen.dart';
import '../controller/CartController.dart';

class CartScreen extends StatefulWidget {
  @override
  _CartScreenState createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  final CartController cartController = Get.put(CartController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Your Cart'),
        actions: [
          PopupMenuButton<String>(
            onSelected: (value) {
              if (value == 'logout') {
                _logout();
              }
            },
            itemBuilder: (BuildContext context) {
              return [
                PopupMenuItem<String>(
                  value: 'logout',
                  child: Row(
                    children: [
                      Icon(Icons.logout),
                      SizedBox(width: 8),
                      Text('Logout'),
                    ],
                  ),
                ),
              ];
            },
          ),
        ],

      ),
      
      body: Obx(() {
        if (cartController.isLoading.value) {
          return Center(child: CircularProgressIndicator());
        } else {
          if (cartController.cartItems.isEmpty) {
            return Center(child: Text('Your cart is empty'));
          }

          return ListView.builder(
            itemCount: cartController.cartItems.length,
            itemBuilder: (context, index) {
              var cartItem = cartController.cartItems[index];

              return Card(
                child: ListTile(
                  title: Text(cartItem['title'].toString() ?? ""),
                  subtitle: Row(
                    children: [
                      IconButton(
                        icon: Icon(Icons.remove),
                        onPressed: () {
                          if (cartItem['quantity'] > 1) {
                            cartController.updateProductQuantity(
                              cartItem['cartId'],
                              cartItem['productId'],
                              cartItem['quantity'] - 1,
                            );
                          }
                        },
                      ),
                      Text(cartItem['quantity'].toString()),
                      IconButton(
                        icon: Icon(Icons.add),
                        onPressed: () {
                          cartController.updateProductQuantity(
                            cartItem['cartId'],
                            cartItem['productId'],
                            cartItem['quantity'] + 1,
                          );
                        },
                      ),
                    ],
                  ),
                  trailing: IconButton(
                    icon: Icon(Icons.delete),
                    onPressed: () {
                      cartController.removeFromCart(
                        cartItem['cartId'],
                        //cartItem['productId'],
                      );
                    },
                  ),
                ),
              );
            },
          );
        }
      }),
    );
  }

  void _logout() {
    Get.snackbar('Logout', 'You have been logged out.');
    Get.offAll(() => LoginScreen());
  }
}


