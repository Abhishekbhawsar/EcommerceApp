import 'dart:async';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'auth/LoginScreen.dart';

class Splashscreen extends StatefulWidget {
  const Splashscreen({super.key});

  @override
  State<Splashscreen> createState() => _SplashscreenState();
}

class _SplashscreenState extends State<Splashscreen> {
  @override
  void initState() {
    // TODO: implement initState
    getSessiong();
    super.initState();
  }

  getSessiong(){
  Timer( Duration(seconds: 3), () {
    Get.to(LoginScreen());
  });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        //backgroundColor: NatureColor.whiteTemp,
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text('Welcome to Splash Screen!'),
            // child: Image.asset('assets/images/mhdlogo.png',fit: BoxFit.fill,),
          ),
        ));
  }
}


