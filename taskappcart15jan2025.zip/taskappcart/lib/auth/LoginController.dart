import 'package:flutter/cupertino.dart';
import 'package:get/get_rx/src/rx_types/rx_types.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import '../screen/CategoryScreen.dart';
import 'package:flutter/material.dart';
class LoginController extends GetxController {
  var emailController = TextEditingController();
  var passwordController = TextEditingController();
  var isPasswordObscured = true.obs; // Reactive variable for password visibility
  var isLoading = false.obs; // Reactive variable for loading state

  // Method to toggle password visibility
  void togglePasswordVisibility() {
    isPasswordObscured.value = !isPasswordObscured.value;
  }

  // Method to perform login action
  void login() async {
    isLoading.value = true;

    String email = emailController.text.trim();
    String password = passwordController.text.trim();

    if (email.isEmpty || password.isEmpty) {
      isLoading.value = false;
      Get.snackbar('Validation Error', 'Email and password cannot be empty');
      return;
    }
   // ${Endpoints.baseUrl}
    var headers = {'Content-Type': 'application/json'};
    var request = http.Request('POST', Uri.parse('https://fakestoreapi.com/auth/login'));
    print('Login email: ${email}');
    print('Login password: ${password}');
    request.body = json.encode({
      "username": email,
      "password": password,
    });
    request.headers.addAll(headers);

    try {
      http.StreamedResponse response = await request.send();
      isLoading.value = false;

      if (response.statusCode == 200) {
        var responseBody = await response.stream.bytesToString();
        var data = jsonDecode(responseBody);
        print('Login successful: $data');
        Get.to(CategoryScreen());
        // Navigate to CategoryScreen
      } else {
        Get.snackbar('Error', 'Login failed. Please try again.');
        print('Error: ${response.reasonPhrase}');
      }
    } catch (e) {
      isLoading.value = false;
      Get.snackbar('Error', 'An error occurred. Please try again.');
      print('Exception: $e');
    }
  }
}

