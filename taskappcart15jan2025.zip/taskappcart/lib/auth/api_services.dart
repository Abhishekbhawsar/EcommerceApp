
class Endpoints {
  Endpoints._();


  static  String testEndpoint = "https://fakestoreapi.com/";

  static const String Login = "auth/login";


}
