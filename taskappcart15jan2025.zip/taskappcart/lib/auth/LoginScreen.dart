import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'LoginController.dart';
class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final LoginController loginController = Get.put(LoginController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Login')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Email TextField
            TextField(
              controller: loginController.emailController,
              decoration: InputDecoration(
                labelText: 'Email',
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.text,
            ),
            SizedBox(height: 20),

            // Password TextField with visibility toggle
            Obx(() {
              bool isObscured = loginController.isPasswordObscured.value;
              return TextField(
                controller: loginController.passwordController,
                obscureText: isObscured,
                decoration: InputDecoration(
                  labelText: 'Password',
                  border: OutlineInputBorder(),
                  suffixIcon: IconButton(
                    icon: Icon(
                      isObscured ? Icons.visibility : Icons.visibility_off,
                    ),
                    onPressed: loginController.togglePasswordVisibility,
                  ),
                ),
              );
            }),
            SizedBox(height: 20),

            // Login Button
            Obx(() {
              return ElevatedButton(
                onPressed: loginController.isLoading.value
                    ? null
                    : () {
                  loginController.login();
                },
                child: loginController.isLoading.value
                    ? CircularProgressIndicator(color: Colors.white)
                    : Text('Login'),
              );
            }),
          ],
        ),
      ),
    );
  }
}


