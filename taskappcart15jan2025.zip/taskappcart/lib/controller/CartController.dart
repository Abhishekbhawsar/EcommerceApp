import 'dart:convert';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;

import '../screen/CartScreen.dart';

  class CartController extends GetxController {
    var cartItems = <Map<String, dynamic>>[]
        .obs; // Observable list of cart items
    var isLoading = false.obs;

    // Function to add a product to the cart
    Future<void> addToCart(int userId, int productId, int quantity) async {
      isLoading.value = true;
      cartItems.clear();

      print("userId========== ${userId}");
      print("productId== ${productId}");
      print("quantity======= ${quantity}");

      final url = Uri.parse('https://fakestoreapi.com/carts');
      final payload = {
        "userId": userId,
        "products": [
          {
            "productId": productId,
            "quantity": quantity
          }
        ]
      };

      try {
        final response = await http.post(
          url,
          headers: {"Content-Type": "application/json"},
          body: jsonEncode(payload),
        );

        if (response.statusCode == 200 || response.statusCode == 201) {
          Get.snackbar('Success', 'Product added to cart successfully');

          // Update cart items dynamically
          var newItem = {
            "cartId": cartItems.length + 1,
            // Example cartId increment
            "productId": productId,
            "title": "Product $productId",
            // Replace with actual product title if needed
            "quantity": quantity
          };
          print("newitem===>${newItem}");
          cartItems.add(newItem);
          Get.to(() => CartScreen());
        } else {
          Get.snackbar('Error', 'Failed to add product to cart');
        }
      } catch (e) {
        Get.snackbar('Error', 'An error occurred: $e');
      } finally {
        isLoading.value = false;
      }
    }


    Future<void> updateProductQuantity(int cartId, int productId,
        int quantity) async {
      isLoading.value = true;

      final url = Uri.parse('https://fakestoreapi.com/carts/$cartId');
      final payload = {
        "productId": productId,
        "quantity": quantity
      };

      try {
        final response = await http.put(
          url,
          headers: {"Content-Type": "application/json"},
          body: jsonEncode(payload),
        );

        if (response.statusCode == 200) {
       //   Get.snackbar('Success', 'Product quantity updated successfully');
          // Update the local cart data
          var updatedCartItem = cartItems.firstWhere((item) => item['productId'] == productId);
          updatedCartItem['quantity'] = quantity;
          cartItems.refresh(); // Refresh the list to update the UI
          Get.snackbar('Success', 'Product quantity updated successfully');
        } else {
          Get.snackbar('Error', 'Failed to update product quantity');
        }
      } catch (e) {
        Get.snackbar('Error', 'An error occurred: $e');
      } finally {
        isLoading.value = false;
      }
    }
    Future<void> removeFromCart(int cartId) async {
      isLoading.value = true;

      try {
        final response = await http.delete(
          Uri.parse('https://fakestoreapi.com/carts/$cartId/remove'),
        );

        if (response.statusCode == 200) {
          // Remove the item from the local list after successful API call
          cartItems.removeWhere((item) => item['cartId'] == cartId);
          Get.snackbar('Success', 'Item removed from cart');
        } else {
          Get.snackbar('Error', 'Failed to remove item from cart');
        }
      } catch (e) {
        Get.snackbar('Error', 'An error occurred: $e');
      } finally {
        isLoading.value = false;
      }
    }
  }