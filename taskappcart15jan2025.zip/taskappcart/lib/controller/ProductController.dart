import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class ProductController extends GetxController {
  var product = {}.obs;
  var isLoading = true.obs;

  void fetchProductDetails(int productId) async {
    isLoading(true);
    try {
      final response = await http.get(Uri.parse('https://fakestoreapi.com/products/$productId'));
      if (response.statusCode == 200) {
        product.value = json.decode(response.body);


      } else {
        Get.snackbar('Error', 'Failed to load product details');
      }
    } catch (e) {
      Get.snackbar('Error', 'An error occurred');
    } finally {
      isLoading(false);
    }
  }
}
